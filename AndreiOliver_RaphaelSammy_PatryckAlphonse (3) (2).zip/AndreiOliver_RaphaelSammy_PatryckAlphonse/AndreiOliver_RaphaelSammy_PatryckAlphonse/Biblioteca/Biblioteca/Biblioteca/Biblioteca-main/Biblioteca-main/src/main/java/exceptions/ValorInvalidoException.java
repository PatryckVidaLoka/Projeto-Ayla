package exceptions;

public class ValorInvalidoException extends Exception {
    public ValorInvalidoException(String msg) {
        super(msg);
    }
}
